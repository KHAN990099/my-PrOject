export function greet(name) {
  return `Hello, ${name}!`;
}

console.log(greet('DocForge'));
